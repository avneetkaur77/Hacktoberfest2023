package com.example.quotesapp

data class Quote(val text: String, val author: String )
//dataclass representing quote