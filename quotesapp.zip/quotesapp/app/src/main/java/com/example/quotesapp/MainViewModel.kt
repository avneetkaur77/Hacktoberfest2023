package com.example.quotesapp

import android.content.Context
import androidx.lifecycle.ViewModel
import com.google.gson.Gson

class MainViewModel(val context: Context): ViewModel() {
    private var quoteList: Array<Quote> = emptyArray()
    private var index = 0

    init { // initialise
        quoteList = loadQuoteFromAssets()
    }

    private fun loadQuoteFromAssets(): Array<Quote> {
        val inputStream = context.assets.open("quotes.json") // ab quotes ko read krne e liye context chahiuye hoga jop mainactivity m h kyoki viewmodel m view ni dal skte
        val size: Int = inputStream.available()// size of inputstream
        val buffer = ByteArray(size) // buffer-will store the file
        inputStream.read(buffer)//reading a file
        inputStream.close()
        val json = String(buffer, Charsets.UTF_8) //converting bytearray into string ,, we have passed buffer which has to be converted along with its encoding
        val gson = Gson() // creating gson object
        return gson.fromJson(json, Array<Quote>::class.java)
    }

    fun getQuote() = quoteList[index]

    fun nextQuote() = quoteList[++index % quoteList.size]

    fun previousQuote() = quoteList[(--index + quoteList.size) % quoteList.size]
}